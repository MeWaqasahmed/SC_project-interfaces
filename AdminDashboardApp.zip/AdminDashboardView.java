import java.awt.*;
import javax.swing.*;

public class AdminDashboardView extends JFrame {
    
    private AdminDashboardController controller;
    
    public AdminDashboardView(AdminDashboardController controller) {
        this.controller = controller;
        this.controller.setView(this);
        initialize();
    }
    
    private void initialize() {
        setTitle("Admin Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        JButton profileButton = new JButton("Profile");
        profileButton.addActionListener(e -> controller.showAdminProfile());
        headerPanel.add(profileButton);
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> controller.logout());
        headerPanel.add(logoutButton);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Welcome message
        JLabel welcomeLabel = new JLabel("Welcome to the Admin Dashboard", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Serif", Font.BOLD, 24));
        add(welcomeLabel, BorderLayout.CENTER);
        
        // Actions panel
        JPanel actionsPanel = new JPanel();
        actionsPanel.setLayout(new GridLayout(3, 2, 10, 10));
        
        JButton viewPendingButton = new JButton("View Pending Lists");
        viewPendingButton.addActionListener(e -> controller.viewPendingLists());
        actionsPanel.add(viewPendingButton);
        
        JButton viewBlockedAccountsButton = new JButton("View Blocked Accounts");
        viewBlockedAccountsButton.addActionListener(e -> controller.viewBlockedAccounts());
        actionsPanel.add(viewBlockedAccountsButton);
        
        JButton addAccountToBlockListButton = new JButton("Add Account to Block List");
        addAccountToBlockListButton.addActionListener(e -> controller.addAccountToBlockList());
        actionsPanel.add(addAccountToBlockListButton);
        
        JButton removeListingButton = new JButton("Remove Listing");
        removeListingButton.addActionListener(e -> controller.removeListing());
        actionsPanel.add(removeListingButton);
        
        add(actionsPanel, BorderLayout.SOUTH);
    }
}
