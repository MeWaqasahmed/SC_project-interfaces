import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class AdminController {
    private final AdminDashboard dashboard;
    private final List<String> blockedAccounts;
    private final List<String> pendingListings;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/admin";
    private static final String DB_USER = "username";
    private static final String DB_PASSWORD = "root";

    public AdminController(AdminDashboard dashboard) {
        this.dashboard = dashboard;
        this.blockedAccounts = new ArrayList<>();
        this.pendingListings = new ArrayList<>();
    }

    public List<String> getBlockedAccounts() {
        return blockedAccounts;
    }

    public List<String> getPendingListings() {
        return pendingListings;
    }

    public void blockAccount(String accountId) {
        blockedAccounts.add(accountId);
        JOptionPane.showMessageDialog(dashboard, "Account ID: " + accountId + " has been blocked.");
        addAccountToBlockedAccountsTable(accountId);
    }

    private void addAccountToBlockedAccountsTable(String accountId) {
        try (Connection conn = DriverManager.getConnection("blocked_account","username" , "");
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO blocked_accounts (account_id) VALUES (?)")) {
            stmt.setString(1, accountId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeBlockedAccount(int index) {
        String accountId = blockedAccounts.get(index - 1);
        blockedAccounts.remove(index - 1);
        JOptionPane.showMessageDialog(dashboard, "Blocked Account ID: " + accountId + " has been removed.");
        removeAccountFromBlockedAccountsTable(accountId);
    }

    private void removeAccountFromBlockedAccountsTable(String accountId) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM blocked_accounts WHERE account_id = ?")) {
            stmt.setString(1, accountId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeListing(String itemId) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM listings WHERE id = ?")) {
            stmt.setString(1, itemId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(dashboard, "Item ID: " + itemId + " has been removed.");
            } else {
                JOptionPane.showMessageDialog(dashboard, "Item ID: " + itemId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPendingItemDetails(String itemId) {
        String details = fetchItemDetailsFromSellerTable(itemId);
        JOptionPane.showMessageDialog(dashboard, "Details for Item ID " + itemId + ": " + details);
    }

    private String fetchItemDetailsFromSellerTable(String itemId) {
        StringBuilder details = new StringBuilder();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM listings WHERE id = ?")) {
            stmt.setString(1, itemId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                details.append("ID: ").append(rs.getString("id")).append("\n");
                details.append("Title: ").append(rs.getString("title")).append("\n");
                details.append("Description: ").append(rs.getString("description")).append("\n");
                details.append("Status: ").append(rs.getString("status")).append("\n");
                details.append("Seller ID: ").append(rs.getString("seller_id")).append("\n");
                details.append("Duration: ").append(rs.getString("duration")).append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return details.toString();
    }

    public void handleAction(String actionCommand) {
        switch (actionCommand) {
            case "View Pending Lists":
                fetchPendingListings();
                dashboard.showPendingList();
                break;
            case "View Blocked Accounts":
                fetchBlockedAccounts();
                dashboard.showBlockedAccounts();
                break;
            case "Add Account to Block List":
                dashboard.showAddToBlockList();
                break;
            case "Remove Listing":
                dashboard.showRemoveListing();
                break;
            default:
                break;
        }
    }

    private void fetchPendingListings() {
        pendingListings.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM listings WHERE status = 'Pending'")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                pendingListings.add(rs.getString("title")); // Adjust column name as necessary
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void fetchBlockedAccounts() {
        blockedAccounts.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM blocked_accounts")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                blockedAccounts.add(rs.getString("account_id")); // Adjust column name as necessary
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
